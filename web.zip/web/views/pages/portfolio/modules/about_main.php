<!-- About Section-->
<section class="page-section bg-primary text-white mb-0" id="about">
            <div class="container">
                <?php 
                include 'about/about_heading.php'; 
                include 'about/about_content.php';
                include 'about/about_buttons.php';
                ?>
            </div>
        </section>