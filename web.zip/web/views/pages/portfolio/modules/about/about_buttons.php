<!-- About Section Button-->
<div class="text-center mt-4">
  <a class="btn btn-xl btn-outline-light" href="https://startbootstrap.com/theme/freelancer/">
    <i class="fas fa-download me-2"></i>
    Free Download!
  </a>
</div>