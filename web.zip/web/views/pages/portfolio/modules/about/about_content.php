<!-- About Section Content-->
<div class="row">
  <div class="col-lg-4 ms-auto">
    <p class="lead">Freelancer is a free bootstrap theme created by Start Bootstrap. The download includes the complete source files including HTML, CSS, and JavaScript as well as optional SASS stylesheets for easy customization.</p>
  </div>
  <div class="col-lg-4 me-auto">
    <p class="lead">You can create your own custom avatar for the masthead, change the icon in the dividers, and add your email address to the contact form to make it fully functional!</p>
  </div>
</div>